public class JavaHelloWorld
{
public static void main {string [] args}
{
System.out.println("Java Hello World");
System.out.println("Hello Again");
}
}
